﻿using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo13;

namespace PluralSight.FakeItEasy.Tests.Demo13
{
    public class CustomerNameFormatterTests
    {
        [TestFixture]
        public class When_formatting_a_customers_name
        {
            [Test]
            public void all_bad_words_should_be_scrubbed()
            {
                //Arrange
                var fakeCustomerNameFormatter = 
                    A.Fake<CustomerNameFormatter>();

                //Act
                fakeCustomerNameFormatter.From(new Customer());

                //Assert
                A.CallTo(fakeCustomerNameFormatter)
                    .Where(x=>x.Method.Name == "ParseBadWordsFrom")
                    .MustHaveHappened(Repeated.Exactly.Twice);
            }
        }
    }
}