﻿using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo06;

namespace PluralSight.FakeItEasy.Tests.Demo06
{
    public class CustomerServiceTests
    {
        [TestFixture]
        public class When_creating_a_customer
        {
            //verify that specific parameter values are passed to the mock object
            [Test]
            public void a_full_name_should_be_created_from_first_and_last_name()
            {
                //Arrange
                var customerToCreateDto = new CustomerToCreateDto
                                              {
                                                  FirstName = "Bob", 
                                                  LastName = "Builder"
                                              };

                var fakeCustomerRepository = A.Fake<ICustomerRepository>();
                var fakeFullNameBuilder = A.Fake<ICustomerFullNameBuilder>();

                var customerService = new CustomerService(
                    fakeCustomerRepository, fakeFullNameBuilder);

                //Act
                customerService.Create(customerToCreateDto);

                //Assert
                A.CallTo(
                    ()=>fakeFullNameBuilder.From(
                        A<string>.That.Matches(s=>s.Equals(customerToCreateDto.FirstName)),
                        A<string>.That.Matches(s=>s.Equals(customerToCreateDto.LastName))))
                .MustHaveHappened();
            }
        }
    }
}