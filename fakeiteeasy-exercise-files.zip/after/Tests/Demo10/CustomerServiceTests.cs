﻿using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo10;

namespace PluralSight.FakeItEasy.Tests.Demo10
{
    public class CustomerServiceTests
    {
        [TestFixture]
        public class When_creating_a_customer
        {
            //verify getter calls
            [Test]
            public void the_workstation_id_should_be_used()
            {
                //Arrange
                var fakeCustomerRepository = A.Fake<ICustomerRepository>();
                var fakeApplicationSettings = A.Fake<IApplicationSettings>();

                A.CallTo(() => fakeApplicationSettings.WorkstationId).Returns(123);
                
                var customerService = new CustomerService(
                    fakeCustomerRepository, 
                    fakeApplicationSettings);

                //Act
                customerService.Create(new CustomerToCreateDto());

                //Assert
                A.CallTo(
                    ()=>fakeApplicationSettings.WorkstationId)
                    .MustHaveHappened();
            }
        }
    }
}