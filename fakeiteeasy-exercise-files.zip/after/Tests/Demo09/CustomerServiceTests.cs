﻿using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo09;

namespace PluralSight.FakeItEasy.Tests.Demo09
{
    public class CustomerServiceTests
    {
        [TestFixture]
        public class When_creating_a_customer
        {
            //verify that a property setter was called on a fake object
            [Test]
            public void the_local_timezone_should_be_set()
            {
                //Arrange
                var fakeCustomerRepository = A.Fake<ICustomerRepository>();

                var customerService = new CustomerService(
                    fakeCustomerRepository);

                //Act
                customerService.Create(new CustomerToCreateDto());

                //Assert
                Assert.That(fakeCustomerRepository.LocalTimeZone, Is.Not.Empty);
                Assert.That(fakeCustomerRepository.LocalTimeZone, Is.Not.Null);

            }
        }
    }
}