﻿using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo12;

namespace PluralSight.FakeItEasy.Tests.Demo12
{
    public class CustomerServiceTests
    {
        [TestFixture]
        public class When_creating_a_new_customer
        {
            //verify that a event was raised
            [Test]
            public void an_email_should_be_sent_to_the_sales_team()
            {
                //Arrange
                var fakeCustomerRepository = A.Fake<ICustomerRepository>();
                var fakeMailingRepository = A.Fake<IMailingRepository>();

                var customerService = new CustomerService(
                    fakeCustomerRepository, fakeMailingRepository);

                //Act
                fakeCustomerRepository.NotifySalesTeam +=
                    Raise.With(new NotifySalesTeamEventArgs("asdf"))
                        .Now;

                //Assert
                A.CallTo(
                    () => fakeMailingRepository.NewCustomerMessage(
                        A<string>.Ignored));
            }
        }
    }
}