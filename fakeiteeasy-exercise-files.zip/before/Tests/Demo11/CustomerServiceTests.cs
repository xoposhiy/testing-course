﻿using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo11;

namespace PluralSight.FakeItEasy.Tests.Demo11
{
    public class CustomerServiceTests
    {
        [TestFixture]
        public class When_creating_a_customer
        {
            //shows auto mocking of sub items in a complext object hierarchy
            [Test]
            public void the_workstationid_should_be_retrieved()
            {
                //Arrange
                var fakeCustomerRepository = A.Fake<ICustomerRepository>();
                var fakeApplicationSettings = A.Fake<IApplicationSettings>();

                A.CallTo(() => fakeApplicationSettings
                                    .SystemConfiguration
                                    .AuditingInformation
                                    .WorkstationId)
                               .Returns(1234);

                var customerService = new CustomerService(
                                            fakeCustomerRepository, 
                                            fakeApplicationSettings);

                //Act
                customerService.Create(new CustomerToCreateDto());

                //Assert
                A.CallTo(
                    ()=>fakeApplicationSettings
                            .SystemConfiguration
                            .AuditingInformation
                            .WorkstationId)
                    .MustHaveHappened();
            }
        }
    }
}