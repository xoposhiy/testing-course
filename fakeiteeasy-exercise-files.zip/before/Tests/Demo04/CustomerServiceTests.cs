﻿using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo04;

namespace PluralSight.FakeItEasy.Tests.Demo04
{
    public class CustomerServiceTests
    {
        [TestFixture]
        public class When_creating_a_customer
        {
            //shows how to deal with out parameters
            [Test]
            public void the_customer_should_be_persisted()
            {
                //Arrange
                var mockCustomerRepository = A.Fake<ICustomerRepository>();
                var mockMailingAddressFactory = A.Fake<IMailingAddressFactory>();




                var customerService = new CustomerService(
                    mockCustomerRepository, mockMailingAddressFactory);

                //Act
                customerService.Create(new CustomerToCreateDto());

                //Assert
                A.CallTo(() => mockCustomerRepository.Save(A<Customer>.Ignored));
            }
        }
    }
}