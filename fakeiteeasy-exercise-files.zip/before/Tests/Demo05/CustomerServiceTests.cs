﻿using System.Collections.Generic;
using FakeItEasy;
using NUnit.Framework;
using PluralSight.FakeItEasy.Code.Demo05;

namespace PluralSight.FakeItEasy.Tests.Demo05
{
    public class CustomerServiceTests
    {
        [TestFixture]
        public class When_creating_a_customer
        {
            [Test]
            //returning different values on subsequent calls
            public void each_customer_should_be_assigned_an_id()
            {
                //Arrange
                var listOfCustomersToCreate = new List<CustomerToCreateDto>
                                                  {
                                                      new CustomerToCreateDto(),
                                                      new CustomerToCreateDto()
                                                  };

                var fakeCustomerRepository = A.Fake<ICustomerRepository>();
                var fakeIdFactory = A.Fake<IIdFactory>();



                var customerService = new CustomerService(
                    fakeCustomerRepository, fakeIdFactory);

                //Act
                customerService.Create(listOfCustomersToCreate);

                //Assert
                A.CallTo(()=>fakeIdFactory.Create()).MustHaveHappened(Repeated.AtLeast.Once);
            }
        }
    }
}