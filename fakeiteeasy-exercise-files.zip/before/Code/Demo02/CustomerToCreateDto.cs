namespace PluralSight.FakeItEasy.Code.Demo02
{
    public class CustomerToCreateDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}