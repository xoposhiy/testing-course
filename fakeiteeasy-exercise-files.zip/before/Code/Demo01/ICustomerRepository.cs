namespace PluralSight.FakeItEasy.Code.Demo01
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}