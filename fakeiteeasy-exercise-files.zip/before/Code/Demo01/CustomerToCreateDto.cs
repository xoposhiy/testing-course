namespace PluralSight.FakeItEasy.Code.Demo01
{
    public class CustomerToCreateDto
    {
        public string City { get; set; }
        public string Name { get; set; }
    }
}