namespace PluralSight.FakeItEasy.Code.Demo06
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}