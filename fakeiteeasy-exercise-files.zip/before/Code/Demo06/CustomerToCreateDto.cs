namespace PluralSight.FakeItEasy.Code.Demo06
{
    public class CustomerToCreateDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}