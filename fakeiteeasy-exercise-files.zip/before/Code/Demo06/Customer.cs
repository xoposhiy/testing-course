namespace PluralSight.FakeItEasy.Code.Demo06
{
    public class Customer
    {
        public string FullName { get; set; }

        public Customer(string fullName)
        {
            FullName = fullName;
        }
    }
}