namespace PluralSight.FakeItEasy.Code.Demo08
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}