namespace PluralSight.FakeItEasy.Code.Demo08
{
    public class Address
    {
    }
}