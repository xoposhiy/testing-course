namespace PluralSight.FakeItEasy.Code.Demo08
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}