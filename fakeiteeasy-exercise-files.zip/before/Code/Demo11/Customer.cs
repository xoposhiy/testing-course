namespace PluralSight.FakeItEasy.Code.Demo11
{
    public class Customer
    {
        public string Name { get; set; }
        public int WorkstationCreatedOn { get; set; }

        public Customer(string name)
        {
            Name = name;
        }
    }
}