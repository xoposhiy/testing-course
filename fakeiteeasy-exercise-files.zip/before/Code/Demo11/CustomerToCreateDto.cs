namespace PluralSight.FakeItEasy.Code.Demo11
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}