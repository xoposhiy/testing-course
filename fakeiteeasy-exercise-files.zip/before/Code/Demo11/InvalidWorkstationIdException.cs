using System;

namespace PluralSight.FakeItEasy.Code.Demo11
{
    public class InvalidWorkstationIdException : Exception
    {
    }
}