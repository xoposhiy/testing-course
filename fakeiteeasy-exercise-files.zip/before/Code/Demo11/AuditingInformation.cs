namespace PluralSight.FakeItEasy.Code.Demo11
{
    public interface IAuditingInformation
    {
        int? WorkstationId { get; set; }
    }
}