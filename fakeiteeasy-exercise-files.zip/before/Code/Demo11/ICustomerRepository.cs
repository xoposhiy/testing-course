namespace PluralSight.FakeItEasy.Code.Demo11
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}