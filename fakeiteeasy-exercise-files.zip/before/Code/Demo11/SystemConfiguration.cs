namespace PluralSight.FakeItEasy.Code.Demo11
{
    public interface ISystemConfiguration
    {
        IAuditingInformation AuditingInformation { get; set; }
    }
}