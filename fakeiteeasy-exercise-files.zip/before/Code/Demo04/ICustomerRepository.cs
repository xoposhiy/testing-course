namespace PluralSight.FakeItEasy.Code.Demo04
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}