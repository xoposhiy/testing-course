using System;

namespace PluralSight.FakeItEasy.Code.Demo04
{
    public class InvalidMailingAddressException : Exception
    {
    }
}