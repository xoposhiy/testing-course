namespace PluralSight.FakeItEasy.Code.Demo04
{
    public class CustomerToCreateDto
    {
        public string Address { get; set; }
        public string Name { get; set; }
    }
}