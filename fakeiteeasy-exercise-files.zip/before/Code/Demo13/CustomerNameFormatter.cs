﻿namespace PluralSight.FakeItEasy.Code.Demo13
{
    public class CustomerNameFormatter
    {
        public string From(Customer customer)
        {
            var firstName = ParseBadWordsFrom(customer.FirstName);
            var lastName = string.Empty;// ParseBadWordsFrom(customer.LastName);

            return string.Format("{0}, {1}", lastName, firstName);
        }

        protected virtual string ParseBadWordsFrom(string value)
        {
            return value.Replace("SAP", string.Empty);
        }
    }
}