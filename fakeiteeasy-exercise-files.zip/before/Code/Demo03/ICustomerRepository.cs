namespace PluralSight.FakeItEasy.Code.Demo03
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}