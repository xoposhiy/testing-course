using System;

namespace PluralSight.FakeItEasy.Code.Demo03
{
    public class InvalidCustomerMailingAddressException : Exception
    {
    }
}