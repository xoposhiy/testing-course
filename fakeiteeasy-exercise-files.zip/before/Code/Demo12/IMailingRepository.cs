namespace PluralSight.FakeItEasy.Code.Demo12
{
    public interface IMailingRepository
    {
        void NewCustomerMessage(string name);
    }
}