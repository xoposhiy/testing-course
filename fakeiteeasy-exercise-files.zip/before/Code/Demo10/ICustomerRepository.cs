namespace PluralSight.FakeItEasy.Code.Demo10
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}