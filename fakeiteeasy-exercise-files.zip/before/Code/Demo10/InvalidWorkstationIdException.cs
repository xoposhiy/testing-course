using System;

namespace PluralSight.FakeItEasy.Code.Demo10
{
    public class InvalidWorkstationIdException : Exception
    {
    }
}