namespace PluralSight.FakeItEasy.Code.Demo05
{
    public interface IIdFactory
    {
        int Create();
    }
}